print "__name__==" + __name__
if __name__=="__main__":
	print "__name__==" + __name__

